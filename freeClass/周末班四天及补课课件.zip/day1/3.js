/**
 * Created by xiao lei on 2016/4/23.
 */
window.onload=function(){
    var oDiv=document.getElementById('div1');
    oDiv.onclick=function(){
        //console.log(confirm('你能坚持到最后吗？'));
        //console.log(oDiv)
       // console.dir(oDiv)
    }
}